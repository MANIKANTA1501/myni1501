package com.queue.Springqueue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringqueueApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringqueueApplication.class, args);
	}

}
