export interface Hospital{
    userNumber:number
    date:Date;
    slot:number;
    requestType:string;
    message:string
    status:string;
}