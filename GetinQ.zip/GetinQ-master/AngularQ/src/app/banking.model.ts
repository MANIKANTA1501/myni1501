export interface Banking{
    userNumber:number
    date:Date;
    requestType:string;
    status:string;
    loanToken:number;
    depositToken:number;
    }