package myfstsprboot.Restaurant;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestaurant {
	@GetMapping(value="/test")
	public String getReq() {
	return "this is get request";
	}

	@GetMapping(value="/test/{username}")
	public String getReqByName(@PathVariable String username) {
	return "this is get request "+username;
	}

	@PostMapping(value="/test")
	public String postReq() {
	return "this is post request ";
	}


	@PutMapping(value="/test")
	public String putReq() {
	return "this is put request ";
	}

	@DeleteMapping(value="/test")
	public String deleteReq() {
	return "this is delete request ";
	}

	

	}

