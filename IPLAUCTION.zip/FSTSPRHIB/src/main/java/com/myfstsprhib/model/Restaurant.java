package com.myfstsprhib.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Restaurant {
	
String name1;
public String getName1() {
	return name1;
}
public void setName1(String name1) {
	this.name1 = name1;
}
@Id
int jerseynumber;
public int getJerseynumber() {
	return jerseynumber;
}
public void setJerseynumber(int jerseynumber) {
	this.jerseynumber = jerseynumber;
}
String baseprice;
public String getBaseprice() {
	return baseprice;
}
public void setBaseprice(String baseprice) {
	this.baseprice = baseprice;
}




}
