package com.myfstsprhib.dao;


import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.dialect.function.TemplateRenderer;
import org.hibernate.mapping.List;
import org.hibernate.sql.Template;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Component;

import com.myfstsprhib.model.Restaurant;

@Component
public class RestaurantDao {
	
	@Autowired
SessionFactory sessionfactory;
	
	@Transactional
public void saveRestaurant(Restaurant restaurant){
		
		Session session=sessionfactory.getCurrentSession();
		
		 session.saveOrUpdate(restaurant);
		
	}
@Transactional
public ArrayList<Restaurant> dispRestaurant(){
	
	Session session=sessionfactory.getCurrentSession();
	
	@SuppressWarnings("unchecked")
	ArrayList<Restaurant> restaurant=(ArrayList<Restaurant>)session.createQuery("from Restaurant").list();
		return restaurant ;
	}
@Transactional
public void delRestaurant(int name2){
	
	Session session=sessionfactory.getCurrentSession();
	
	 Restaurant res=(Restaurant) session.get(Restaurant.class,name2);
	session.delete(res);
}
@Transactional
public Restaurant dispbyIdRest(Integer jerseynumber){
	
	Session session=sessionfactory.getCurrentSession();
	
	 Restaurant res=(Restaurant) session.get(Restaurant.class,jerseynumber);
	 //System.out.println(res);
	 return res;
}

}
 
