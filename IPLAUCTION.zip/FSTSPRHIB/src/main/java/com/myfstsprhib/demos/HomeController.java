package com.myfstsprhib.demos;


import java.util.ArrayList;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.myfstsprhib.dao.RestaurantDao;
import com.myfstsprhib.model.Restaurant;

@Controller
public class HomeController {
	

	@RequestMapping(value = "/")
	public String home(Locale locale, Model model) {
	
		return "home2";
	}
	
	@Autowired
	RestaurantDao restaurantdao;
	
	@RequestMapping(value = "/getdata")
	public String saveRestaurant(@ModelAttribute Restaurant restaurant ) {
		 
		restaurantdao.saveRestaurant(restaurant);
		
		return "home";
	}
	
	
	@RequestMapping(value = "/displaydata")
	public String dispRestaurant(Model model) {
	ArrayList<Restaurant> restaurant = restaurantdao.dispRestaurant(); 
	model.addAttribute("Restaurant",restaurant);
		return "home3";
	}
	
	@RequestMapping(value = "/deletedata")
	public String delRestaurant(@RequestParam int name2 ) {
		 
		restaurantdao.delRestaurant(name2);
		
		return "home2";
	}
	@RequestMapping(value = "/displaybyId")
	public String dispbyIdRest(Model m,@RequestParam("jerseynumber") int id ) {
		 
		Restaurant res=restaurantdao.dispbyIdRest(id);
		m.addAttribute("Restaurant",res);
		return "home4";
	}
	
	
	
}
