package com.mystask.pojo;

public class Customerobj {


		public Customerobj(String customerFname, String customerMname, String customeraddr) {
		super();
		this.customerFname = customerFname;
		this.customerMname = customerMname;
		this.customeraddr = customeraddr;
	}
		public String getCustomerFname() {
		return customerFname;
	}
	public void setCustomerFname(String customerFname) {
		this.customerFname = customerFname;
	}
	public String getCustomerMname() {
		return customerMname;
	}
	public void setCustomerMname(String customerMname) {
		this.customerMname = customerMname;
	}
	public String getCustomeraddr() {
		return customeraddr;
	}
	public void setCustomeraddr(String customeraddr) {
		this.customeraddr = customeraddr;
	}
		String customerFname;
		String customerMname;
		String customeraddr;
		}
