package com.mystask.service;

import java.util.Scanner;

import com.mystask.dao.CUSTDAO;
import com.mystask.pojo.Customerobj;

public class custservice {

public static void main(String []args) {

CUSTDAO dao = new CUSTDAO();
Customerobj customer = new Customerobj("virat","kohli","bang");

String result = CUSTDAO.InsertCustomer(customer);
System.out.println(result);
}

}
