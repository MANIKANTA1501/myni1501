package com.mystask.service;

import java.util.Scanner;

import com.mystask.dao.CUSTDAO;
import com.mystask.pojo.Customerobj;

public class custservice {

public static void main(String []args) {

@SuppressWarnings("resource")
Scanner sc = new Scanner(System.in);
System.out.println("Enter values:");
String a=sc.nextLine();
String b=sc.nextLine();
String c=sc.nextLine();
Customerobj customer = new Customerobj(a, b, c);

String result = CUSTDAO.InsertCustomer(customer);

}

}
