package com.mystask.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mystask.dbutil.CUSTCONN;
import com.mystask.pojo.Customerobj;
//import com.mydemos.pojo.Student;

public class CUSTDAO {
	public static String retriveid(String CustomerFName,String CustomerMName){

        String custid="";

        String name1=CustomerFName.substring(0,2);

        String name2=CustomerMName.substring(0,2);

        try{

        Connection con=CUSTCONN.getConnection();

       

   

    String sql1="SELECT trim(lpad(custid.nextval,3,0)) FROM DUAL";

   

    PreparedStatement stat1=con.prepareStatement(sql1);

    ResultSet rs = stat1.executeQuery();

   

    if ( rs.next() )

    {

      custid = rs.getString(1);

      //System.out.println(cust_id);

    }         

    else

    {

      return "cannot access sequence";

    }

        }

        catch(Exception e){

              e.printStackTrace();

        }



       

       

        return name1+name2+custid;

       

  }
public static String InsertCustomer(Customerobj customer) {
try {
Connection con = CUSTCONN.getConnection();
//String custid="";
//custid=CustomerFName.substring(0,2)+CustomerMName.substring(0,2);
String sql = "insert into customersave values(?,?,?,?)";

PreparedStatement stat = con.prepareStatement(sql);

stat.setString(1, customer.getCustomerFname());
stat.setString(2, customer.getCustomerMname());
stat.setString(3, customer.getCustomeraddr());
stat.setString(4, retriveid(customer.getCustomerFname(),customer.getCustomerMname()));

int res= stat.executeUpdate();

if(res>0)

return "customer saved";





}

catch (Exception e) {

e.printStackTrace();

}



return "Cannot save Customer";



}

}



	